sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("sap.com.POCMKTORG.controller.MainView", {
		onInit: function () {
			//get access to the tree table and binding associated to calculate the count 
			this._oDataModel = this.getOwnerComponent().getModel();
			this._tempModel = new JSONModel();
			this._Router = this.getOwnerComponent().getRouter();
			//	this._currentSelection = {};
			this.getView().setModel(this._tempModel, "TempModel");
			this.getView().setModel(this.getOwnerComponent().getModel('campaignVH'), "campaign");
			this.folderCount();
		},
		onSearch : function(oEvent){
			this._o
		},
		folderCount: function () {
			// this._ODataModel.read("");
		},
		onCreate: function (oEvent) {
			//create a popover
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("popoverId", "sap.com.POCMKTORG.view.Popover", this);
				this.getView().addDependent(this._oPopover);
				//this._oPopover.bindElement("/ProductCollection/0");
			}
			this._oPopover.openBy(oEvent.getSource());
		},
		onDelete: function (oEvent) {
			//Popover with message if no item is selected.
			if (this.getCurrentSelection() === undefined) {
				this.genericPopOver('Delete', 'Choose folder to Delete!');
			} else {
				// a warning before deletion. 
				this.deleteWarningPopOver();
			}

			//Popover to confirm the message deletion
			// Message Toast for success and failure of the Deletion itself.

		},
		deleteWarningPopOver: function () {
			if (!this.deletionPopOver) {
				this.deletionPopOver = new sap.m.Dialog({
					title: 'Delete',
					content: [
						new sap.m.Text("indeletionTextId", {
							text: "Deleting Folder will delete its contents. Are you sure?"
						}).addStyleClass('sapUiSmallMarginTop sapUiMediumMarginBeginEnd')
					],
					beginButton: new sap.m.Button({
						text: 'Delete',
						press: function () {
							this.deleteRecord();
							this.deletionPopOver.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: 'Exit',
						press: function () {
							this.deletionPopOver.close();
						}.bind(this)
					})
				});
				//to get access to the global model
				this.getView().addDependent(this.deletionPopOver);
			}

			this.deletionPopOver.open();

		},

		onRename: function (oEvent) {

			if (this.getCurrentSelection() === undefined) {
				this.genericPopOver('Rename', 'Choose Folder to Rename!');
			} else {
				// Popup for renaming
				var currentSelection = this.getCurrentSelection();
				if (!this.renameDialog) {
					this.renameDialog = new sap.m.Dialog({
						title: 'Rename Folder',
						draggable: true,
						resizable: true,
						content: [new sap.m.Label({
								text: "Folder's Name",
								required: true
							}).addStyleClass('sapUiTinyMarginBeginEnd'),
							new sap.m.Input("renameFolderId", {
								type: "Text",
								value: currentSelection.name,
								width: '80%'
							}).addStyleClass('sapUiTinyMarginBeginEnd')
						],
						beginButton: new sap.m.Button({
							text: 'Save',
							press: function (oEvent) {
								this.updateRecord(oEvent);
								this.renameDialog.close();
							}.bind(this)
						}),
						endButton: new sap.m.Button({
							text: 'Close',
							press: function () {
								this.renameDialog.close();
							}.bind(this)
						})
					});

					//to get access to the global model
					this.getView().addDependent(this.renameDialog);
				} else {

					var content = this.renameDialog.getContent();
					for (var each in content) {
						if (content[each].getId() === 'renameFolderId') {
							content[each].setValue(currentSelection.name);
						}
					}
				}

				this.renameDialog.open();
			}

		},
		updateRecord: function (oEvent) {
			//	oSelection.name;
			var aControls = oEvent.getSource().getParent().getContent();
			for (var each in aControls) {
				if (aControls[each].getId() === 'renameFolderId') {
					var sName = aControls[each].getValue();
				}
			}
			var _currentSelectionContext = this.getCurrentSelectionContext();
			var oPayLoad = {};
			if (_currentSelectionContext !== undefined) {
				// oPayLoad.db_key = _currentSelection.db_key;
				// oPayLoad.parentnode_id = _currentSelection.parentnode_id;
				// oPayLoad.hierarchy_level = _currentSelection.hierarchy_level;
				// oPayLoad.drillstate = _currentSelection.drillstate;
				// oPayLoad.is_public = _currentSelection.is_public;
				oPayLoad.name = sName;
				// oPayLoad.object_type = _currentSelection.object_type;
				// oPayLoad.reference_object_id = _currentSelection.reference_object_id;
			}
			this._oDataModel.update(_currentSelectionContext.sPath, oPayLoad, {
				success: this._fnEntityUpdateSuccess.bind(this),
				error: this._fnEntityUpdateFailure.bind(this)
			});
		},
		_fnEntityUpdateSuccess: function () {
			this._oDataModel.refresh();
			sap.m.MessageToast.show("Updated Successfully");
		},

		_fnEntityUpdateFailure: function () {
			sap.m.MessageToast.show("Updation Failed");
		},

		onCreateObject: function (oEvent) {

			//create a popover
			if (!this._oObjectref) {
				this._oObjectref = sap.ui.xmlfragment("objecrefId", "sap.com.POCMKTORG.view.ObjectReference", this);
				this.getView().addDependent(this._oObjectref);
				//this._oPopover.bindElement("/ProductCollection/0");
			}
			this._oObjectref.openBy(oEvent.getSource());

			/*eslint-disable*/
			//  open the dialog fragment
			//        if(!this._f4dialog){
			//        	this._f4dialog = new sap.m.Dialog({
			//        		title : "F4 Dialog",
			//        		stretch : true,
			// resizable : true,
			// draggable : true,
			// contentWidth : '50%',
			//        		content : [
			//        			    	 sap.ui.xmlview("f4Dialog", "sap.com.POCMKTORG.view.f4campaignview")
			//        			],
			//        		endButton: new sap.m.Button({
			// 	text: 'Close',
			// 	press: function () {
			// 		this._f4dialog.close();
			// 	}.bind(this)
			// })	

			//        	});
			//        	this.getView().addDependent(this._f4dialog);
			//        }
			//        this._f4dialog.open();
			////////////////////////////////////////////////////////////////////////////////   

			//if(!this._campF4dialog){
			////	this._campF4dialog = sap.ui.xmlfragment("f4Dialog", "sap.com.POCMKTORG.view.campaignF4", this);
			//    this._campF4dialog =  sap.ui.core.mvc.View("f4Dialog", {
			//    	viewName : "sap.com.POCMKTORG.view.F4campaignview"
			//    });

			//	//this.getView().addDependent(this._campF4dialog);
			//	//this._campF4dialog.setModel(this.getOwnerComponent().getModel("campaignVH"),'campaign');
			//}  
			//this._campF4dialog.open();
			//this._Router.navTo("f4campaignview");
		},

		onCreateObjectReference: function (oEvent) {
			//	         open the dialog fragment
			if (!this._f4dialog) {
				this._f4dialog = new sap.m.Dialog({
					title: "F4 Dialog",
					stretch: true,
					resizable: true,
					draggable: true,
					contentWidth: '50%',
					content: [
						sap.ui.xmlview("f4Dialog", "sap.com.POCMKTORG.view.f4campaignview")
					],
					endButton: new sap.m.Button({
						text: 'Close',
						press: function () {
							this._f4dialog.close();
						}.bind(this)
					})

				});
				this.getView().addDependent(this._f4dialog);
			}
			this._f4dialog.open();
		},
		genericPopOver: function (sTitle, sText) {
			if (!this.genericDialog) {
				this.genericDialog = new sap.m.Dialog({
					title: sTitle,
					content: [
						new sap.m.Text({
							text: sText
						}).addStyleClass('sapUiSmallMarginTop sapUiMediumMarginBeginEnd')
					],
					endButton: new sap.m.Button({
						text: 'Close',
						press: function () {
							this.genericDialog.close();
						}.bind(this)
					})
				});
				//to get access to the global model
				this.getView().addDependent(this.genericDialog);
			} else {
				this.genericDialog.setTitle(sTitle);
				var content = this.genericDialog.getContent();
				for (var each in content) {
					content[each].setText(sText);
				}
			}
			this.genericDialog.open();
		},

		onCreateFolder: function (oEvent) {
			if (!this.pressDialog) {
				this.pressDialog = new sap.m.Dialog({
					title: 'Create Folder',
					draggable: true,
					resizable: true,
					content: [new sap.m.Label({
							text: "Folder's Name",
							required: true
						}).addStyleClass('sapUiTinyMarginBeginEnd'),
						new sap.m.Input("inFolderId", {
							type: "Text",
							width: '80%'
						}).addStyleClass('sapUiTinyMarginBeginEnd')
					],
					beginButton: new sap.m.Button({
						text: 'Save',
						press: function () {
							this.createRecord();
							this.pressDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: 'Close',
						press: function () {
							this.pressDialog.close();
						}.bind(this)
					})
				});

				//to get access to the global model
				this.getView().addDependent(this.pressDialog);
			}

			this.pressDialog.open();
		},
		createRecord: function (oEvent) {
			/*eslint-disable*/
			// read the context 
			var oList = this.pressDialog.getContent();
			var oInFld;
			for (var each in oList) {
				if (oList[each].sId === "inFolderId") {
					oInFld = oList[each];
				}
			}
			var oPayLoad = this.createPayloadForFolderCreation(oInFld.getValue());
			oInFld.setValue("");
			// Odata call to create
			var sPath = "/ZMKT_HIER";
			this._oDataModel.create(sPath, oPayLoad, {
				async: false,
				success: this._fnEntityCreated.bind(this),
				error: this._fnEntityFailed.bind(this)
			});
		},

		deleteRecord: function () {
			var _currentSelection = this.getCurrentSelectionContext();
			if (_currentSelection !== undefined) {
				this._oDataModel.remove(_currentSelection.sPath, {
					success: this._fnEntityDeletedSuccess.bind(this),
					error: this._fnEntityDeletedFailure.bind(this)
				});
			}
		},

		_fnEntityDeletedSuccess: function () {
			this._oDataModel.refresh();
			sap.m.MessageToast.show("Deleted Successfully");
		},

		_fnEntityDeletedFailure: function () {
			sap.m.MessageToast.show("Deleted Failed");
		},
		_fnEntityCreated: function () {
			this._oDataModel.refresh();
			sap.m.MessageToast.show("Created Successfully");

		},
		_fnEntityFailed: function () {
			sap.m.MessageToast.show("Creation Failed");
		},
		createPayloadForFolderCreation: function (sFolder) {
			if (sFolder) {
				var oPayLoad = {};
				var _currentSelection = this.getCurrentSelection();
				if (_currentSelection != undefined) {
					oPayLoad.parentnode_id = _currentSelection.db_key;
					if (_currentSelection.object_type === 'FOLDER') {
						oPayLoad.hierarchy_level = _currentSelection.hierarchy_level + 1;
					} else {
						oPayLoad.hierarchy_level = _currentSelection.hierarchy_level;
					}
				} else {
					//	oPayLoad.parentnode_id = "";
					oPayLoad.hierarchy_level = 0;
				}

				oPayLoad.drillstate = "";
				oPayLoad.is_public = false;
				oPayLoad.name = sFolder;
				oPayLoad.object_type = "FOLDER";
				oPayLoad.reference_object_id = "";
				return oPayLoad;

			}
			return undefined;
		},
		onSelectionChange: function (oEvent) {
			/*eslint-disable*/
			// first approach.
			// var oCon = oEvent.getParameter("rowContext");
			// this._currentSelection = this._oDataModel.getProperty(oCon.sPath);
		},

		getCurrentSelection: function () {
			var oTable = this.getView().byId("treeTable");
			var oContext = oTable.getContextByIndex(oTable.getSelectedIndex());
			if (oContext === null) {
				oContext = undefined;
				return oContext;
			} else {
				return this._oDataModel.getProperty(oContext.sPath);
			}

		},

		getCurrentSelectionContext: function () {
			var oTable = this.getView().byId("treeTable");
			var oContext = oTable.getContextByIndex(oTable.getSelectedIndex());
			if (oContext === null) {
				oContext = undefined;
				return oContext;
			} else {
				return oContext;
			}

		},
		onExit: function () {
			if (this._oPopover) {
				this._oPopover.destroy();
			}
			if (this.pressDialog) {
				this.pressDialog.destroy();
			}

			if (this.selectionPopOver) {
				this.selectionPopOver.destroy();
			}
			if (this.deletionPopOver) {
				this.deletionPopOver.destroy();
			}
			if (this.genericPopOver) {
				this.genericPopOver.destroy();
			}
			if (this.renameDialog) {
				this.renameDialog.destroy();
			}

		}

	});
});