function initModel() {
	var sUrl = "/sap/opu/odata/sap/C_NIMI_MKT_CAMPAIGNVH_CDS/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}