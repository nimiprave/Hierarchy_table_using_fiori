sap.ui.define([
	"sap/com/POCMKTORG/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});